package com.air.airtest.controller.worker;

public abstract class BaseController {

}
