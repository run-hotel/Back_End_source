package com.air.airtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirtestApplicationTests {

	@Test
	void contextLoads() {
	}

}
